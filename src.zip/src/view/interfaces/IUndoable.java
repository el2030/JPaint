package view.interfaces;

public interface IUndoable {

	void undo();
	void redo();
	
}
