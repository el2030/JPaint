package view.interfaces;

public interface IGroup {

}
