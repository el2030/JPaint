package view.interfaces;

public interface IMoveCommand {

	void execute();

}
