package view.interfaces;

public interface ISubject{

	void registerObserver(IObserver o);
	
}
