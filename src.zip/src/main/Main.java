package main;

import model.JPaint;

public class Main {
    public static void main(String[] args){
    	new JPaint().run();
    }
}


