package controller;

import view.interfaces.IObserver;
import view.interfaces.ISubject;

public class Subject implements ISubject {

	@Override
	public void registerObserver(IObserver o) {
		// TODO Auto-generated method stub
		
	}

}
