package controller;

import view.interfaces.IObserver;

public class Observer implements IObserver {

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

}
