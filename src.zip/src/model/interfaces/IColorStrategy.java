package model.interfaces;

import java.awt.*;

public interface IColorStrategy {
Color getColor();
}
